# UNISEFE Clone

A tiny native WordPress plugin that clones posts, pages and custom post types with one click.

**Single PHP file. Zero JavaScript. Zero AJAX. Zero settings. Zero external dependencies.**

## Philosophy

UNISEFE Clone follows a simple rule:

> Native WordPress first. PHP first. JavaScript only when truly necessary, and Vanilla JS only. AJAX only when technically justified.

For cloning content, WordPress already provides everything required, so the plugin uses only native admin actions, nonces, capabilities, metadata APIs, taxonomy APIs and redirects.

## Features

- Clone posts
- Clone pages
- Clone custom post types
- Copies content and excerpt
- Copies post hierarchy and menu order
- Copies comment and ping status
- Copies post password
- Copies post metadata
- Copies taxonomy terms
- Creates the clone as a draft
- Assigns the clone to the current user
- Opens the cloned item directly in the native WordPress editor
- Excludes transient editor metadata such as `_edit_lock` and `_edit_last`
- Native WordPress permissions and nonce protection
- No settings page
- No JavaScript
- No AJAX
- No CSS
- No framework

## Installation

1. Download the plugin ZIP or the `unisefe-clone.php` file.
2. Upload it through **Plugins → Add New → Upload Plugin**, or place the plugin folder in `wp-content/plugins/`.
3. Activate **UNISEFE Clone**.
4. Open Posts, Pages or a supported custom post type.
5. Click **Clone** in the native row actions.

The cloned item is created as a draft and opened immediately in the WordPress editor.

## Architecture

The complete plugin runtime is contained in one PHP file:

```text
unisefe-clone.php
```

The clone request uses the native WordPress admin action flow:

```text
Row action
    ↓
admin.php?action=unisefe_clone
    ↓
Nonce + capability validation
    ↓
wp_insert_post()
    ↓
Metadata + taxonomy copy
    ↓
wp_safe_redirect()
    ↓
Native WordPress editor
```

No client-side runtime is required.

## Security

UNISEFE Clone uses:

- WordPress nonce verification
- `current_user_can( 'edit_post', ... )`
- Sanitized request values
- WordPress post/meta/taxonomy APIs
- `wp_safe_redirect()`

## Version

### 0.0.1

Initial UNISEFE release, derived from the original Lean Bunker Cloner by Riccardo Bastillo and revised around a stricter native-WordPress, single-file architecture.

## Author

**Riccardo Bastillo**

## License

GPL-3.0-or-later
