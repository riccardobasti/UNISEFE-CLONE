<?php
/**
 * Plugin Name: UNISEFE Clone
 * Description: Clone posts, pages and custom post types with one click. Single file, native WordPress, zero JavaScript, zero AJAX.
 * Version: 0.0.1
 * Author: Riccardo Bastillo
 * License: GPL-3.0-or-later
 * Text Domain: unisefe-clone
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Add the native "Clone" row action.
 */
function unisefe_clone_row_action( $actions, $post ) {
    if ( ! $post instanceof WP_Post ) {
        return $actions;
    }

    if ( 'revision' === $post->post_type || ! current_user_can( 'edit_post', $post->ID ) ) {
        return $actions;
    }

    $url = wp_nonce_url(
        add_query_arg(
            array(
                'action' => 'unisefe_clone',
                'post'   => $post->ID,
            ),
            admin_url( 'admin.php' )
        ),
        'unisefe_clone_' . $post->ID
    );

    $actions['unisefe_clone'] = sprintf(
        '<a href="%1$s" aria-label="%2$s">%3$s</a>',
        esc_url( $url ),
        esc_attr__( 'Clone this item', 'unisefe-clone' ),
        esc_html__( 'Clone', 'unisefe-clone' )
    );

    return $actions;
}
add_filter( 'post_row_actions', 'unisefe_clone_row_action', 10, 2 );
add_filter( 'page_row_actions', 'unisefe_clone_row_action', 10, 2 );

/**
 * Clone the selected post using the native WordPress admin action flow.
 */
function unisefe_clone_action() {
    $post_id = isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0;
    $nonce   = isset( $_GET['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ) : '';

    if ( ! $post_id || ! wp_verify_nonce( $nonce, 'unisefe_clone_' . $post_id ) ) {
        wp_die( esc_html__( 'Invalid clone request.', 'unisefe-clone' ) );
    }

    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        wp_die( esc_html__( 'You are not allowed to clone this item.', 'unisefe-clone' ) );
    }

    $post = get_post( $post_id );

    if ( ! $post instanceof WP_Post || 'revision' === $post->post_type ) {
        wp_die( esc_html__( 'Source item not found.', 'unisefe-clone' ) );
    }

    $new_id = wp_insert_post(
        array(
            'post_author'           => get_current_user_id(),
            'post_content'          => $post->post_content,
            'post_content_filtered' => $post->post_content_filtered,
            'post_title'            => $post->post_title . ' ' . __( '(Copy)', 'unisefe-clone' ),
            'post_excerpt'          => $post->post_excerpt,
            'post_status'           => 'draft',
            'post_type'             => $post->post_type,
            'comment_status'        => $post->comment_status,
            'ping_status'           => $post->ping_status,
            'post_password'         => $post->post_password,
            'post_parent'           => $post->post_parent,
            'menu_order'            => $post->menu_order,
            'post_mime_type'        => $post->post_mime_type,
            'post_name'             => '',
        ),
        true
    );

    if ( is_wp_error( $new_id ) ) {
        wp_die( esc_html( $new_id->get_error_message() ) );
    }

    foreach ( get_post_meta( $post_id ) as $key => $values ) {
        if ( '_edit_lock' === $key || '_edit_last' === $key ) {
            continue;
        }

        foreach ( $values as $value ) {
            add_post_meta( $new_id, $key, maybe_unserialize( $value ) );
        }
    }

    foreach ( get_object_taxonomies( $post->post_type ) as $taxonomy ) {
        $terms = wp_get_object_terms( $post_id, $taxonomy, array( 'fields' => 'ids' ) );

        if ( ! is_wp_error( $terms ) ) {
            wp_set_object_terms( $new_id, $terms, $taxonomy );
        }
    }

    wp_safe_redirect( admin_url( 'post.php?post=' . $new_id . '&action=edit' ) );
    exit;
}
add_action( 'admin_action_unisefe_clone', 'unisefe_clone_action' );
